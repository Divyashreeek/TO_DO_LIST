const todoInput = document.querySelector("#todo__input") 
const todoAddBtn = document.querySelector(".todo_add_btn")
const body =document.body;

todoAddBtn.addEventListener("click", ()=>{
    const inputValue = todoInput.value
    const todolistul = document.querySelector(".todo_list")
    const li =document.createElement("li")
    const liInnerHtml<li class="todo___list_lis"> 
<div>${inputValue}</div>

<div>

    <button class="done">done</button>
     <button class="remove">remove</button>

</div> </li>

li.innerHTML- liInnerHtml

if(inputValue === ""){ alert("Please Add Your Task")

}else{

todolistUl.append(li)

body.addEventListener("click", (eventObject)=>{ 
    if(eventobject.target.classList.contains("done")){
         const todoTask eventObject.target.parentElement.previousElementSibling; 
         todoTask.style.textDecoration = "line-through"
         todoTask.style.color="hsla(57,88%,86%,0.600)"
    }
    if(eventObject.target.classList.contains("remove")){
        const removeTodotask=eventObject.target.parentElement.parentElement
        removeTodaTask.remove()
    }
)

